package io.github.takusan23.twitteroauth;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.RequestToken;
import twitter4j.conf.ConfigurationBuilder;

public class MainActivity extends AppCompatActivity {

    private EditText consumer_key_EditText;
    private EditText consumer_secret_EditText;
    private Button login_Button;
    private TextView response_TextView;
    private TwitterFactory twitterFactory;
    private RequestToken request_token;
    private Twitter twitter;

    public static String consumerKey = "";
    public static String consumerSecret = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        consumer_key_EditText = findViewById(R.id.consumer_key_EditText);
        consumer_secret_EditText = findViewById(R.id.consumer_secret_EditText);
        login_Button = findViewById(R.id.login_button);
        response_TextView = findViewById(R.id.response_TextView);

        consumerKey = consumer_key_EditText.getText().toString();
        consumerSecret = consumer_secret_EditText.getText().toString();

        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setDebugEnabled(true)
                .setOAuthConsumerKey(consumerKey)
                .setOAuthConsumerSecret(consumerSecret)
                .setOAuthAccessToken(null)
                .setOAuthAccessTokenSecret(null);

        twitterFactory = new TwitterFactory(cb.build());
        twitter = twitterFactory.getInstance();
        //飛ばす
        getLoginScreen();
    }

    /*ログイン画面*/
    private void getLoginScreen() {
        login_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AsyncTask<Void,Void,Void>(){
                    @Override
                    protected Void doInBackground(Void... aVoid) {
                        try {
                            request_token = twitter.getOAuthRequestToken();
                            String url = request_token.getAuthenticationURL();
                        } catch (TwitterException e) {
                            e.printStackTrace();
                        }
                        return null;
                    }
                }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

            }
        });
    }
}
